﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Reflection;

namespace DocuSignTest
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public Startup(IConfiguration configuration)
        {
            this.Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc(options => options.EnableEndpointRouting = false)
                .AddApplicationPart(Assembly.GetEntryAssembly());
            //.AddNewtonsoftJson((options) => { options.AddCustomJsonOptions(); });
            //services.Configure<FormOptions>((options) => { options.AddCustomFormOptions(); });
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            //services.AddTransient<DapperContext>();
            //services.AddTransient<Commonfunctions>();
            //services.AddSingleton<IDocusignAuthenticator, DocusignAuthenticator>();
            //services.AddSingleton<IDocusignService, DocusignService>();

            //services.AddScoped<IEmailSender, EmailSender>();
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",

                    builder => builder.AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader());
            });

            // Register the Swagger generator
            services.AddEndpointsApiExplorer();


            services.AddSwaggerGen(option =>
            {
                option.SwaggerDoc("v1", new OpenApiInfo { Title = "DocuSign API", Version = "v1", Description = "DocuSign API." });
                option.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    In = ParameterLocation.Header,
                    Description = @"JWT Authorization header using the Bearer sc heme. 
                      Enter 'Bearer' [space] and then your token in the text input below.
                      Example: 'Bearer 12345abcdef'",
                    Name = "Authorization",
                    Type = SecuritySchemeType.Http,
                    BearerFormat = "JWT",
                    Scheme = "Bearer"

                });
                ////option.DocumentFilter<RemoveSchemasFilter>();
                //var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                //var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                //option.IncludeXmlComments(xmlPath);

                option.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type=ReferenceType.SecurityScheme,
                                Id="Bearer"
                            }
                        },
                        new string[]{}
                    }
                });
            });
            services.AddControllers(options => options.SuppressImplicitRequiredAttributeForNonNullableReferenceTypes = true);
            services.AddAuthentication();
            //.AddOAuth("DocuSign", options =>
            //{
            //    options.ClientId = Configuration["DocuSign:ClientId"];
            //    options.ClientSecret = Configuration["DocuSign:ClientSecret"];
            //    options.CallbackPath = new PathString("/ds/callback");
            //    options.AuthorizationEndpoint = "https://account-d.docusign.com/oauth/auth";
            //    options.TokenEndpoint = "https://account-d.docusign.com/oauth/token";
            //    options.UserInformationEndpoint = "https://account-d.docusign.com/oauth/userinfo";
            //});
            // VERY IMPORTANT FOR THE DOCUSIGN WEBHOOKS
            services.Configure<KestrelServerOptions>(options =>
            {
                options.AllowSynchronousIO = true;
            });
        }

        public void Configure(IApplicationBuilder appBuilder, IWebHostEnvironment env, ILoggerFactory factory)
        {

            //factory.AddNLogConfiguration();
            //appBuilder.UseMiddleware<ResponseFormatterMiddleware>();
            appBuilder.UseStaticFiles();
            appBuilder.UseRouting();
            appBuilder.UseAuthorization();
            appBuilder.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });


            if (env.IsDevelopment() || env.IsProduction())
            {
                appBuilder.UseDeveloperExceptionPage();
                appBuilder.UseSwagger();

                // specifying the Swagger JSON endpoint.
                appBuilder.UseSwaggerUI(c =>
                {
                    c.DefaultModelsExpandDepth(-1); // Disable swagger schemas at bottom                                  
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "DocuSign");

                });
            }

            //appBuilder.AddSslOptions();
            appBuilder.UseHttpsRedirection();
            appBuilder.UseMvc();
        }

        private Type GetDocumentSigningType()
        {
            var serviceType = Configuration["DocumentSigningService:type"];
            if (string.IsNullOrEmpty(serviceType))
                return null;

            var type = Type.GetType(serviceType);
            return type != null ? type : null;
        }
    }
}

public class RemoveSchemasFilter : IDocumentFilter
{
    private static readonly string[] _ignoredPaths = {
            "/configuration",
            "/outputcache/{region}"
        };
    public void Apply(OpenApiDocument swaggerDoc, DocumentFilterContext context)
    {

        foreach (var ignorePath in _ignoredPaths)
        {
            swaggerDoc.Paths.Remove(ignorePath);
        }
    }

}
