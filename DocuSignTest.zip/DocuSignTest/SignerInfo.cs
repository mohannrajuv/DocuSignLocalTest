﻿namespace DocuSignTest
{
    public class SignerInfo
    {
        public string SignerEmail { get; set; }
        public string SignerName { get; set; }
        public string CCEmail { get; set; }
        public string CCName { get; set; }
    }
}
