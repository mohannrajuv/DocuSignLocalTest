﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DocuSignTest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]   
    public class DocuSignController : ControllerBase
    {
        [HttpGet]
        [Route("GetName")]
        public string GetName()
        {
            return "Hi Mohan";
        }
        [HttpPost]
        [Route("SendEnvelope")]
        public IActionResult SendEnvelope(SignerInfo signerInfo)
        {
            string envelopeId = DocuSignExample.SendEnvelope(signerInfo);
            return Ok("EnvelopeId: " + envelopeId);
        }
    }

}
