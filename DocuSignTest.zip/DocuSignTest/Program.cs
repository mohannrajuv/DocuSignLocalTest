using DocuSignTest;
using Microsoft.AspNetCore.Hosting;

public class Program
{
    public static void Main(string[] args)
    {
        CreateHostBuilder(args).Build().Run();
    }

    public static IHostBuilder CreateHostBuilder(string[] args)
    {
        IConfigurationBuilder configBuilder = new ConfigurationBuilder().GetAppSettingConfiguration();
        return Host.CreateDefaultBuilder(args)
        .ConfigureWebHostDefaults(webBuilder =>
        {
            webBuilder.UseStartup<Startup>();
            webBuilder.UseConfiguration(configBuilder.Build());

        }).ConfigureWebHost(config =>
        {
            config.UseUrls("http://*:7081");


        }).UseWindowsService();

    }

}
