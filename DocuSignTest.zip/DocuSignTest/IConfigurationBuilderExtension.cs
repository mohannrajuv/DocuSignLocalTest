﻿namespace DocuSignTest
{
    public static class IConfigurationBuilderExtension
    {
        public static IConfigurationBuilder GetAppSettingConfiguration(this IConfigurationBuilder configurationBuilder)
        {
            string parentFolderPath = System.IO.Directory.GetParent(AppDomain.CurrentDomain.BaseDirectory).Parent.FullName;
            var configBuilder = configurationBuilder.SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                //.AddYamlFile("appsettings.yml")
                .AddJsonFile(System.IO.Path.Combine(parentFolderPath, "config", "appsettings.json"), true)
                .AddCommandLine(Environment.GetCommandLineArgs());
            return configBuilder;
        }
    }

}
